package com.spot_the_ballgame.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.makeramen.roundedimageview.RoundedImageView;
import com.spot_the_ballgame.Game_Details_Screen_Act;
import com.spot_the_ballgame.Game_Two_Act;
import com.spot_the_ballgame.Interface.Factory;
import com.spot_the_ballgame.Model.Carousel_Model;
import com.spot_the_ballgame.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class View_Pager_Adapter extends PagerAdapter {
    private List<Carousel_Model.Banner_Contest> banner_contests;
    private Context context;

    private String str_rule_id;
    private String str_status_onclick;
    private String str_end_game;
    private ArrayList<String> stringArrayList = new ArrayList<>();

    private String str_imagepath;
    private String str_correct_ans, str_wrong_ans, str_skip;
    private long lng_seconds;
    private long different_milli_seconds;
    private String str_seconds, str_2x_powerup, str_contest_id, str_entry_fees;
    private String str_categories;
    String str_team_a_path;
    String str_local_host;
    int height = 0;
    String str_status;
    private LayoutInflater inflater;

    public View_Pager_Adapter(ArrayList<Carousel_Model.Banner_Contest> banner_contest, FragmentActivity activity) {
        this.banner_contests = banner_contest;
        this.context = activity;
    }

    @Override
    public int getCount() {
        return banner_contests.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.album_card, container, false);
        RoundedImageView imageView;
        CardView card_view_in_album_card;
        imageView = view.findViewById(R.id.image);
        card_view_in_album_card = view.findViewById(R.id.card_view_in_album_card);
        String str_local_host = Factory.BASE_URL_FOR_IMAGE_LOCAL_HOST;
        str_imagepath = str_local_host + banner_contests.get(position).getImage_url();
//        Log.e("str_imagepath", str_imagepath);
        Glide.with(context).load(str_imagepath)
                .thumbnail(Glide.with(context).load(str_imagepath))
                .into(imageView);


        str_status = banner_contests.get(position).play_status;
        str_categories = banner_contests.get(position).categories;
//        Log.e("str_categories_carr", str_categories);

//        Log.e("outside", str_status);
        final String t2 = banner_contests.get(position).end_date_time;
        stringArrayList.add(t2);
//        Log.e("t22222subvv", t2);
//        Log.e("t22222sub", t2.substring(11, 19));
        Collections.sort(stringArrayList);
//        Log.e("stringArrayList", stringArrayList.toString());

        /*Getting Current Time*/
        Calendar calendar = Calendar.getInstance();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat mdformat = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
        mdformat.setTimeZone(TimeZone.getTimeZone("GMT"));
        String strDate = mdformat.format(calendar.getTime());


        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
        try {
            Date current_system_time = mdformat.parse(strDate);
            Date end_date_api = sdf.parse(t2);
//            Log.e("end_date_api", String.valueOf(end_date_api));
//            Log.e("parse_cur_system_time", String.valueOf(current_system_time));
            different_milli_seconds = end_date_api.getTime() - current_system_time.getTime();
//            Log.e("different_milli_seconds", String.valueOf(different_milli_seconds));
        } catch (ParseException e) {
            e.printStackTrace();
        }


        String fees_type = banner_contests.get(position).fee_type;

        card_view_in_album_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_correct_ans = banner_contests.get(position).correct_mark;
                str_wrong_ans = banner_contests.get(position).wrong_mark;
                str_skip = banner_contests.get(position).skip;


                Toast.makeText(context, "" + banner_contests.get(position), Toast.LENGTH_SHORT).show();
                Carousel_Model.Banner_Contest s1 = banner_contests.get(position);
                str_categories = banner_contests.get(position).categories;
                str_imagepath = banner_contests.get(position).categories_image;
                str_rule_id = banner_contests.get(position).rules_id;
                str_status_onclick = banner_contests.get(position).play_status;
                str_end_game = banner_contests.get(position).end_date_time;
                String prize_type = banner_contests.get(position).prize_type;
//                Log.e("str_status_onclick", str_status_onclick);
//                Log.e("str_rule_id", str_rule_id);
//                Log.e("rules_name", banner_contests.get(position).rules_name);
//                Log.e("end_date_time", banner_contests.get(position).end_date_time);
                if (str_categories.equalsIgnoreCase("Trivia_Image")
                        || str_categories.equalsIgnoreCase("Trivia")
                        || str_categories.equalsIgnoreCase("Prediction")) {
                    //  Toast.makeText(context, "Rule ID :" + " " + str_rule_id, Toast.LENGTH_SHORT).show();
                    String fees_type = banner_contests.get(position).fee_type;
                    if (fees_type.equalsIgnoreCase("0")) {
                        str_entry_fees = "Free";
                    } else {
                        str_entry_fees = banner_contests.get(position).entry_fee;
                    }
                    Intent intent1 = new Intent(context, Game_Two_Act.class);
                    str_seconds = banner_contests.get(position).seconds;
                    str_2x_powerup = banner_contests.get(position).powerup_count;
                    str_contest_id = banner_contests.get(position).contest_id;
                    intent1.putExtra("int_onclcik_value", String.valueOf(s1));
                    intent1.putExtra("game_name", banner_contests.get(position).contest_name);
                    intent1.putExtra("prize_amount", banner_contests.get(position).price);
                    intent1.putExtra("end_time", str_end_game);
                    intent1.putExtra("count_down_seconds", str_seconds);
                    intent1.putExtra("str_2x_powerup", str_2x_powerup);
                    intent1.putExtra("str_contest_id", str_contest_id);
                    intent1.putExtra("str_entry_fees", str_entry_fees);
                    intent1.putExtra("str_rule_id", str_rule_id);
                    intent1.putExtra("str_status_onclick", str_status_onclick);
                    intent1.putExtra("str_imagepath", str_imagepath);
                    intent1.putExtra("str_categories", str_categories);

                    intent1.putExtra("str_correct_ans", str_correct_ans);
                    intent1.putExtra("str_wrong_ans", str_wrong_ans);
                    intent1.putExtra("str_skip", str_skip);
                    intent1.putExtra("prize_type", prize_type);
                    intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(intent1);
                }
                if (str_categories.equalsIgnoreCase("Spot the ball")) {
                    String fees_type = banner_contests.get(position).fee_type;
                    if (fees_type.equalsIgnoreCase("0")) {
                        str_entry_fees = "Free";
                    } else {
                        str_entry_fees = banner_contests.get(position).entry_fee;
                    }
                    str_seconds = banner_contests.get(position).seconds;
                    str_2x_powerup = banner_contests.get(position).powerup_count;
                    str_contest_id = banner_contests.get(position).contest_id;
//                    Log.e("str_secondsdsds", str_seconds);
                    Intent intent1 = new Intent(context, Game_Details_Screen_Act.class);
                    intent1.putExtra("int_onclcik_value", String.valueOf(s1));
                    intent1.putExtra("game_name", banner_contests.get(position).contest_name);
                    intent1.putExtra("prize_amount", banner_contests.get(position).price);
                    intent1.putExtra("end_time", str_end_game);
                    intent1.putExtra("count_down_seconds", str_seconds);
                    intent1.putExtra("str_2x_powerup", str_2x_powerup);
                    intent1.putExtra("str_contest_id", str_contest_id);
                    intent1.putExtra("str_entry_fees", str_entry_fees);
                    intent1.putExtra("str_rule_id", str_rule_id);
                    intent1.putExtra("str_status_onclick", str_status_onclick);
                    intent1.putExtra("str_imagepath", str_imagepath);
                    intent1.putExtra("str_categories", str_categories);
                    intent1.putExtra("int_onclcik_value", String.valueOf(s1));
                    intent1.putExtra("str_correct_ans", str_correct_ans);
                    intent1.putExtra("str_wrong_ans", str_wrong_ans);
                    intent1.putExtra("str_skip", str_skip);
                    intent1.putExtra("prize_type", prize_type);
                    intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(intent1);
                }
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "" + banner_contests.get(position), Toast.LENGTH_SHORT).show();
            }
        });
        container.addView(view, 0);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }
}
