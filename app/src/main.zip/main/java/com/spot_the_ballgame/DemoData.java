package com.spot_the_ballgame;

/**
 * Created by yuweichen on 16/5/3.
 */
public class DemoData {

    public static int[] covers = {R.mipmap.ic_cover_1, R.mipmap.ic_cover_1, R.mipmap.ic_cover_1, R.mipmap.ic_cover_1,
            R.mipmap.ic_cover_1, R.mipmap.ic_cover_1, R.mipmap.ic_cover_1, R.mipmap.ic_cover_1};

}
