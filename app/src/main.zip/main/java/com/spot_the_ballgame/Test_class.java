package com.spot_the_ballgame;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.spot_the_ballgame.Interface.APIInterface;
import com.spot_the_ballgame.Interface.Factory;
import com.spot_the_ballgame.Model.UserModel;

import org.json.JSONObject;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Test_class extends Activity {
    EditText et_email_id_in_signin, et_pwd_in_signin;
    Button btn_login, btn_show_hide_crnt_pwd;
    String str_email_id, str_pwd;
    ProgressDialog pd;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_sign_in);

        et_email_id_in_signin = findViewById(R.id.et_email_id_in_signin);
        et_pwd_in_signin = findViewById(R.id.et_pwd_in_signin);
        btn_login = findViewById(R.id.btn_login);
        btn_show_hide_crnt_pwd = findViewById(R.id.btn_show_hide_crnt_pwd);
        pd = new ProgressDialog(Test_class.this);
        et_pwd_in_signin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!(et_pwd_in_signin.getText().toString().length() == 0)) {
                    btn_show_hide_crnt_pwd.setVisibility(View.VISIBLE);
                    btn_show_hide_crnt_pwd.setBackgroundResource((R.drawable.eye_open));
                } else {
                    btn_show_hide_crnt_pwd.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        btn_show_hide_crnt_pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btn_show_hide_crnt_pwd.getText().toString().equals("Show")) {
                    btn_show_hide_crnt_pwd.setText("Hide");
                    et_pwd_in_signin.setTransformationMethod(null);
                    et_pwd_in_signin.setSelection(et_pwd_in_signin.getText().toString().length());
                    btn_show_hide_crnt_pwd.setBackgroundResource((R.drawable.eye_hide));
                } else {
                    btn_show_hide_crnt_pwd.setText("Show");
                    et_pwd_in_signin.setTransformationMethod(new PasswordTransformationMethod());
                    et_pwd_in_signin.setSelection(et_pwd_in_signin.getText().toString().length());
                    btn_show_hide_crnt_pwd.setBackgroundResource((R.drawable.eye_open));
                }
            }
        });


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_pwd_in_signin.onEditorAction(EditorInfo.IME_ACTION_DONE);
                str_email_id = et_email_id_in_signin.getText().toString();
                str_pwd = et_pwd_in_signin.getText().toString();

                Log.e("str_email_id", str_email_id);
                Log.e("str_pwd", str_pwd);

//                if (str_email_id.isEmpty()) {
//                    Toast_Message.showToastMessage(Test_class.this, getResources().getString(R.string.enter_your_email_txt));
//                } else if (!Patterns.EMAIL_ADDRESS.matcher(str_email_id).matches()) {
//                    Toast_Message.showToastMessage(Test_class.this, getResources().getString(R.string.pls_enter_valid_email_address));
//                    et_email_id_in_signin.requestFocus();
//                } else if (str_pwd.isEmpty()) {
//                    Toast_Message.showToastMessage(Test_class.this, getResources().getString(R.string.pls_enter_your_pwd));
//                } else if (str_pwd.length() <= 6) {
//                    Toast_Message.showToastMessage(Test_class.this, getResources().getString(R.string.pls_enter_valid_pwd));
//                    et_pwd_in_signin.requestFocus();
//                } else {
                    Get_Email_SignIn_Details();

            }
        });
    }

    private void Get_Email_SignIn_Details() {
        try {
            str_email_id = et_email_id_in_signin.getText().toString();
            str_pwd = et_pwd_in_signin.getText().toString();
            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("source_detail", "email");
//            jsonObject.put("email", str_email_id);
//            jsonObject.put("password", str_pwd);
            jsonObject.put("usname", str_email_id);
            jsonObject.put("pwd", str_pwd);
            APIInterface apiInterface = Factory.getClient();

            pd.setMessage("Loading...");
            pd.show();
            pd.setCancelable(false);
            ProgressBar progressbar = pd.findViewById(android.R.id.progress);
            progressbar.getIndeterminateDrawable().setColorFilter(Color.parseColor("#000000"), android.graphics.PorterDuff.Mode.SRC_IN);

            Log.e("Json_value", jsonObject.toString());
            Call<UserModel> call = apiInterface.NORMAL_LOGIN_RESPONSE_CALL("application/json", jsonObject.toString());
            call.enqueue(new Callback<UserModel>() {
                @Override
                public void onResponse(Call<UserModel> call, Response<UserModel> response) {
                    if (response.code() == 200) {
                        if (response.isSuccessful()) {
                            String str_f_name, str_l_name, str_phone_no, str_username, str_image, str_walet, str_money, str_email, str_active, str_verified, str_code, str_status, str_message, str_api_token;
                            str_status = Objects.requireNonNull(response.body()).status;
                            str_message = response.body().message;
                            if (str_status.equalsIgnoreCase("success")) {
                                str_f_name = response.body().datum.first_name;
                                str_l_name = response.body().datum.last_name;
                                str_email = response.body().datum.email;
                                str_phone_no = response.body().datum.phoneno;
                                str_username = response.body().datum.username;
                                str_image = response.body().datum.image;
                                str_walet = response.body().datum.walet;
                                str_money = response.body().datum.money;
                                str_active = response.body().datum.verified;
                                str_verified = response.body().datum.active;
                                str_api_token = response.body().api_token;
//                                SessionSave.SaveSession("Token_value", str_api_token, Test_class.this);

                                Toast.makeText(Test_class.this,"Success",Toast.LENGTH_LONG).show();
                            }
                        }
                    } else if (response.code() == 403) {
                        Toast_Message.showToastMessage(Test_class.this, Objects.requireNonNull(response.body()).toString());
                    } else if (response.code() == 500) {
                        Toast_Message.showToastMessage(Test_class.this, response.message());
                    }
                }

                @Override
                public void onFailure(Call<UserModel> call, Throwable t) {

                }
            });


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
